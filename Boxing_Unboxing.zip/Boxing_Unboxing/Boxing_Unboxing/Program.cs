﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace box
{
    class Program
    {
        static void Main(string[] args)
        {
            //boxing
            int i = 15;
            object obj = i;         
            Console.WriteLine(obj);

            //unboxing
            int j = (int)obj;
            Console.Write(j);       
            Console.Read();
        }
    }
}
