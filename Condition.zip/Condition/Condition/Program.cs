﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.Write("Enter age : ");
            age = Convert.ToInt32(Console.ReadLine());

            if (age > 0)
            {
                if (age >= 18 && age < 60)
                {
                    Console.Write("Adult");
                }
                else if (age < 18)
                {
                    Console.Write("Teenager");
                }
                else if (age > 60)
                {
                    Console.Write("Senior Citizen");
                }
            }
            else {
                Console.Write("Birth Pending");
            }

            Console.ReadKey();
        }
    }
}
