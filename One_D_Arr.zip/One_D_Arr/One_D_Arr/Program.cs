﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace One_
{
    class Program
    {
        static void Main(string[] args)
        {
            int[]a = new int[3];
            a[0] = 7;
            a[1] = 8;
            a[2] = 9;

            foreach (int i in a)
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }
    }
}
